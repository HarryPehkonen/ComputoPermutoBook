#!/bin/bash
# Run nested_arithmetic example
# Usage: ./run.sh

echo "Running nested_arithmetic example..."
echo "Command: computo  script.json"
echo ""

computo  script.json

echo ""
echo "Expected output:"
cat expected.json
echo ""
