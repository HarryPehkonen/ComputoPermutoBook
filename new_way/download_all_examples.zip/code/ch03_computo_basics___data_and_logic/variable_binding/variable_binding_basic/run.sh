#!/bin/bash
# Run variable_binding_basic example
# Usage: ./run.sh

echo "Running variable_binding_basic example..."
echo "Command: computo  script.json"
echo ""

computo  script.json

echo ""
echo "Expected output:"
cat expected.json
echo ""
