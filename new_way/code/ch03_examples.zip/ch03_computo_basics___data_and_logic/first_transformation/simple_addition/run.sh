#!/bin/bash
# Run simple_addition example
# Usage: ./run.sh

echo "Running simple_addition example..."
echo "Command: computo  script.json"
echo ""

computo  script.json

echo ""
echo "Expected output:"
cat expected.json
echo ""
