#!/bin/bash
# Run modulo_remainder example
# Usage: ./run.sh

echo "Running modulo_remainder example..."
echo "Command: computo  script.json"
echo ""

computo  script.json

echo ""
echo "Expected output:"
cat expected.json
echo ""
